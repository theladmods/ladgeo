import type { Point, Segment, DriverRoute, Vehicle } from "../types";

export const EXACT_THRESHOLD = 11;
export const VEHICLE_COLORS = [
  "#2563eb", "#16a34a", "#dc2626", "#9333ea", "#ea580c", "#0891b2", "#be185d", "#d97706",
];

export function createId() {
  return Math.random().toString(36).slice(2, 10);
}

export function formatDistance(value: number) {
  return `${value.toFixed(1)} km`;
}

export function formatDuration(totalMinutes: number) {
  const rounded = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(rounded / 60);
  const minutes = rounded % 60;
  if (hours === 0) return `${minutes} min`;
  return `${hours}h ${minutes.toString().padStart(2, "0")}m`;
}

export function formatCoordinate(value: number) {
  return value.toFixed(5);
}

export function haversineKm(a: Point, b: Point) {
  const R = 6371;
  const dLat = toRadians(b.lat - a.lat);
  const dLng = toRadians(b.lng - a.lng);
  const lat1 = toRadians(a.lat);
  const lat2 = toRadians(b.lat);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return R * c;
}

function toRadians(value: number) {
  return (value * Math.PI) / 180;
}

function buildDistanceMatrix(start: Point, stops: Point[]) {
  const all = [start, ...stops];
  return all.map((a) => all.map((b) => haversineKm(a, b)));
}

function calcRouteDistance(order: number[], matrix: number[][], returnToStart: boolean) {
  let total = 0;
  let cur = 0;
  for (const s of order) {
    total += matrix[cur][s + 1];
    cur = s + 1;
  }
  if (returnToStart) total += matrix[cur][0];
  return total;
}

function solveExact(matrix: number[][], n: number, returnToStart: boolean) {
  const INF = Number.POSITIVE_INFINITY;
  const sub = 1 << n;
  const dp = Array.from({ length: sub }, () => Array(n).fill(INF));
  const par = Array.from({ length: sub }, () => Array(n).fill(-1));
  for (let e = 0; e < n; e++) dp[1 << e][e] = matrix[0][e + 1];
  for (let mask = 1; mask < sub; mask++) {
    for (let e = 0; e < n; e++) {
      if (!(mask & (1 << e))) continue;
      const pm = mask ^ (1 << e);
      if (!pm) continue;
      for (let pe = 0; pe < n; pe++) {
        if (!(pm & (1 << pe))) continue;
        const cand = dp[pm][pe] + matrix[pe + 1][e + 1];
        if (cand < dp[mask][e]) { dp[mask][e] = cand; par[mask][e] = pe; }
      }
    }
  }
  const full = sub - 1;
  let best = INF, bestE = 0;
  for (let e = 0; e < n; e++) {
    const cand = dp[full][e] + (returnToStart ? matrix[e + 1][0] : 0);
    if (cand < best) { best = cand; bestE = e; }
  }
  const order: number[] = [];
  let cm = full, ce = bestE;
  while (cm !== 0) {
    order.unshift(ce);
    const pe = par[cm][ce];
    cm ^= 1 << ce;
    ce = pe;
    if (ce === -1 && cm !== 0) break;
  }
  return { order, distance: best };
}

function solveHeuristic(matrix: number[][], n: number, returnToStart: boolean) {
  const remaining = new Set(Array.from({ length: n }, (_, i) => i));
  const route: number[] = [];
  let cur = 0;
  while (remaining.size > 0) {
    let next = -1, best = Number.POSITIVE_INFINITY;
    for (const c of remaining) {
      if (matrix[cur][c + 1] < best) { best = matrix[cur][c + 1]; next = c; }
    }
    route.push(next); remaining.delete(next); cur = next + 1;
  }
  let bestRoute = [...route];
  let bestDist = calcRouteDistance(bestRoute, matrix, returnToStart);
  let improved = true;
  while (improved) {
    improved = false;
    for (let i = 0; i < bestRoute.length - 1; i++) {
      for (let k = i + 1; k < bestRoute.length; k++) {
        const cand = [...bestRoute.slice(0, i), ...bestRoute.slice(i, k + 1).reverse(), ...bestRoute.slice(k + 1)];
        const d = calcRouteDistance(cand, matrix, returnToStart);
        if (d + 0.0001 < bestDist) { bestRoute = cand; bestDist = d; improved = true; }
      }
    }
  }
  return { order: bestRoute, distance: bestDist };
}



function buildSegments(start: Point, stops: Point[], speedKmh: number, serviceMin: number): Segment[] {
  const segs: Segment[] = [];
  let elapsed = 0;
  let prev = start;
  for (const stop of stops) {
    const d = haversineKm(prev, stop);
    const t = (d / speedKmh) * 60;
    elapsed += t;
    segs.push({ from: prev.name, to: stop.name, distanceKm: d, driveMinutes: t, etaMinutes: elapsed });
    elapsed += serviceMin;
    prev = stop;
  }
  return segs;
}

// Clarke-Wright savings algorithm for multi-vehicle routing
export function buildDriverRoutes(
  start: Point,
  stops: Point[],
  vehicles: Vehicle[],
  serviceMinutes: number,
  returnToStart: boolean
): DriverRoute[] {
  if (stops.length === 0 || vehicles.length === 0) return [];

  // Sort stops by priority: high > medium > low
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  const sortedStops = [...stops].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

  const parsedVehicles = vehicles.map((v) => ({
    ...v,
    capacity: parseFloat(v.capacityKg) || 500,
    speed: parseFloat(v.speedKmh) || 40,
  }));

  if (parsedVehicles.length === 1) {
    // Single vehicle: just optimize all stops
    const matrix = buildDistanceMatrix(start, sortedStops);
    const solver = sortedStops.length <= EXACT_THRESHOLD
      ? solveExact(matrix, sortedStops.length, returnToStart)
      : solveHeuristic(matrix, sortedStops.length, returnToStart);
    const optimized = solver.order.map((i) => sortedStops[i]);
    const segs = buildSegments(start, optimized, parsedVehicles[0].speed, serviceMinutes);
    const totalWeight = optimized.reduce((s, p) => s + p.packageWeight, 0);
    const totalDist = solver.distance;
    const totalDrive = (totalDist / parsedVehicles[0].speed) * 60;
    const totalSvc = optimized.length * serviceMinutes;
    return [{
      vehicle: vehicles[0],
      stops: optimized,
      segments: segs,
      totalDistanceKm: totalDist,
      totalDriveMinutes: totalDrive,
      totalServiceMinutes: totalSvc,
      totalMinutes: totalDrive + totalSvc,
      totalWeightKg: totalWeight,
    }];
  }

  // Multi-vehicle: greedy bin packing by capacity, then optimize each route
  const routes: Point[][] = parsedVehicles.map(() => []);
  const loads: number[] = parsedVehicles.map(() => 0);

  for (const stop of sortedStops) {
    // Find vehicle with most remaining capacity that can fit this stop
    let bestVehicle = -1;
    let bestRemaining = -1;
    for (let i = 0; i < parsedVehicles.length; i++) {
      const remaining = parsedVehicles[i].capacity - loads[i];
      if (remaining >= stop.packageWeight && remaining > bestRemaining) {
        bestRemaining = remaining;
        bestVehicle = i;
      }
    }
    // If no vehicle can fit it, assign to least loaded
    if (bestVehicle === -1) {
      bestVehicle = loads.reduce((minI, l, i) => l < loads[minI] ? i : minI, 0);
    }
    routes[bestVehicle].push(stop);
    loads[bestVehicle] += stop.packageWeight;
  }

  return routes.map((routeStops, vi) => {
    const v = parsedVehicles[vi];
    const vehicle = vehicles[vi];
    if (routeStops.length === 0) return null;
    const matrix = buildDistanceMatrix(start, routeStops);
    const solver = routeStops.length <= EXACT_THRESHOLD
      ? solveExact(matrix, routeStops.length, returnToStart)
      : solveHeuristic(matrix, routeStops.length, returnToStart);
    const optimized = solver.order.map((i) => routeStops[i]);
    const segs = buildSegments(start, optimized, v.speed, serviceMinutes);
    const totalWeight = optimized.reduce((s, p) => s + p.packageWeight, 0);
    const totalDist = solver.distance;
    const totalDrive = (totalDist / v.speed) * 60;
    const totalSvc = optimized.length * serviceMinutes;
    return {
      vehicle,
      stops: optimized,
      segments: segs,
      totalDistanceKm: totalDist,
      totalDriveMinutes: totalDrive,
      totalServiceMinutes: totalSvc,
      totalMinutes: totalDrive + totalSvc,
      totalWeightKg: totalWeight,
    } as DriverRoute;
  }).filter(Boolean) as DriverRoute[];
}
