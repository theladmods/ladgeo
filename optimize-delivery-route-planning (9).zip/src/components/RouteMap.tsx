import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Point, DriverRoute } from "../types";

// Fix leaflet default icon paths
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

type Props = {
  start: Point;
  driverRoutes: DriverRoute[];
  returnToStart: boolean;
};

function createNumberedIcon(label: string, color: string, isHub = false) {
  const size = isHub ? 38 : 32;
  const svg = `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${size / 2}" cy="${size / 2}" r="${size / 2 - 2}" fill="${color}" stroke="white" stroke-width="2.5"/>
      <text x="${size / 2}" y="${size / 2 + 5}" text-anchor="middle" font-size="${isHub ? 11 : 13}" font-weight="bold" fill="white" font-family="system-ui,sans-serif">${label}</text>
    </svg>
  `;
  return L.divIcon({
    html: svg,
    className: "",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });
}

export function RouteMap({ start, driverRoutes, returnToStart }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layersRef = useRef<L.Layer[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;

    if (!mapRef.current) {
      mapRef.current = L.map(containerRef.current, {
        center: [start.lat, start.lng],
        zoom: 12,
        zoomControl: true,
      });

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(mapRef.current);
    }

    const map = mapRef.current;

    // Clear previous layers
    layersRef.current.forEach((layer) => map.removeLayer(layer));
    layersRef.current = [];

    const allPoints: L.LatLng[] = [];

    // Draw hub marker
    const hubIcon = createNumberedIcon("HUB", "#0f172a", true);
    const hubMarker = L.marker([start.lat, start.lng], { icon: hubIcon })
      .bindPopup(`<div style="font-family:system-ui"><b>🏠 ${start.name}</b><br/>Hub / Dispatch Centre<br/><small>${start.lat.toFixed(5)}, ${start.lng.toFixed(5)}</small></div>`);
    hubMarker.addTo(map);
    layersRef.current.push(hubMarker);
    allPoints.push(L.latLng(start.lat, start.lng));

    // Draw each driver route
    driverRoutes.forEach((route) => {
      const color = route.vehicle.color || "#2563eb";
      const routePoints: [number, number][] = [[start.lat, start.lng]];

      route.stops.forEach((stop, si) => {
        const icon = createNumberedIcon(`${si + 1}`, color);
        const capKg = parseFloat(route.vehicle.capacityKg) || 0;
        const priorityBadge = stop.priority === "high" ? "🔴" : stop.priority === "medium" ? "🟡" : "🟢";
        const marker = L.marker([stop.lat, stop.lng], { icon })
          .bindPopup(`
            <div style="font-family:system-ui;min-width:180px">
              <b>${priorityBadge} ${stop.name}</b><br/>
              <span style="color:${color};font-weight:600">${route.vehicle.name}</span> • Stop ${si + 1}<br/>
              📦 ${stop.packageWeight} kg | Priority: ${stop.priority}<br/>
              🛣 ${route.segments[si]?.distanceKm.toFixed(1)} km leg<br/>
              ⏱ ETA +${Math.round(route.segments[si]?.etaMinutes ?? 0)} min<br/>
              <small>${stop.lat.toFixed(5)}, ${stop.lng.toFixed(5)}</small>
            </div>
          `);
        marker.addTo(map);
        layersRef.current.push(marker);
        routePoints.push([stop.lat, stop.lng]);
        allPoints.push(L.latLng(stop.lat, stop.lng));
        void capKg;
      });

      if (returnToStart && route.stops.length > 0) {
        routePoints.push([start.lat, start.lng]);
      }

      // Draw OSRM real-road route using public routing API
      if (route.stops.length > 0) {
        const coords = routePoints.map(([lat, lng]) => `${lng},${lat}`).join(";");
        const url = `https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson`;

        fetch(url)
          .then((r) => r.json())
          .then((data) => {
            if (data.routes && data.routes[0]) {
              const geojson = data.routes[0].geometry;
              const polyline = L.geoJSON(geojson, {
                style: { color, weight: 5, opacity: 0.82, dashArray: undefined },
              });
              polyline.addTo(map);
              layersRef.current.push(polyline);
            } else {
              // Fallback to straight-line if OSRM fails
              const poly = L.polyline(routePoints, { color, weight: 4, opacity: 0.7, dashArray: "8 6" });
              poly.addTo(map);
              layersRef.current.push(poly);
            }
          })
          .catch(() => {
            const poly = L.polyline(routePoints, { color, weight: 4, opacity: 0.7, dashArray: "8 6" });
            poly.addTo(map);
            layersRef.current.push(poly);
          });
      }
    });

    // Fit map bounds
    if (allPoints.length > 1) {
      const bounds = L.latLngBounds(allPoints);
      map.fitBounds(bounds.pad(0.15));
    } else if (allPoints.length === 1) {
      map.setView(allPoints[0], 13);
    }
  }, [start, driverRoutes, returnToStart]);

  // Resize map on container resize
  useEffect(() => {
    const obs = new ResizeObserver(() => mapRef.current?.invalidateSize());
    if (containerRef.current) obs.observe(containerRef.current);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className="h-[520px] w-full rounded-3xl overflow-hidden border border-slate-200 shadow-xl shadow-slate-200/60 z-0"
      style={{ zIndex: 0 }}
    />
  );
}
