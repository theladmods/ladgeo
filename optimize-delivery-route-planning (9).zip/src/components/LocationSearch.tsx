import { useState, useRef, useEffect, useCallback } from "react";
import type { NominatimResult } from "../types";

type Props = {
  placeholder?: string;
  onSelect: (name: string, lat: string, lng: string) => void;
  label?: string;
  defaultValue?: string;
};

export function LocationSearch({ placeholder = "Search location…", onSelect, label, defaultValue = "" }: Props) {
  const [query, setQuery] = useState(defaultValue);
  const [results, setResults] = useState<NominatimResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const search = useCallback((q: string) => {
    if (q.trim().length < 3) { setResults([]); setOpen(false); return; }
    setLoading(true);
    fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=6&addressdetails=0`,
      { headers: { "Accept-Language": "en" } }
    )
      .then((r) => r.json())
      .then((data: NominatimResult[]) => {
        setResults(data);
        setOpen(data.length > 0);
      })
      .catch(() => setResults([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => search(query), 420);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [query, search]);

  // Close on outside click
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  function handleSelect(result: NominatimResult) {
    const name = result.display_name.split(",")[0].trim();
    setQuery(result.display_name);
    setOpen(false);
    onSelect(name, result.lat, result.lon);
  }

  function handleGeolocate() {
    if (!navigator.geolocation) return;
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`,
          { headers: { "Accept-Language": "en" } }
        )
          .then((r) => r.json())
          .then((data: { display_name: string }) => {
            const name = data.display_name.split(",")[0].trim();
            setQuery(data.display_name);
            onSelect(name, latitude.toFixed(6), longitude.toFixed(6));
          })
          .catch(() => {
            onSelect("My Location", latitude.toFixed(6), longitude.toFixed(6));
          })
          .finally(() => setLoading(false));
      },
      () => setLoading(false),
      { timeout: 8000 }
    );
  }

  return (
    <div ref={containerRef} className="relative w-full">
      {label && <span className="block text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 mb-1.5">{label}</span>}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => results.length > 0 && setOpen(true)}
            className="w-full rounded-2xl border border-slate-200 bg-white pl-4 pr-10 py-3 text-sm text-slate-900 outline-none transition focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
            placeholder={placeholder}
          />
          {loading && (
            <span className="absolute right-3 top-1/2 -translate-y-1/2">
              <svg className="animate-spin h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
              </svg>
            </span>
          )}
        </div>
        <button
          type="button"
          title="Use my location"
          onClick={handleGeolocate}
          className="flex items-center justify-center rounded-2xl border border-slate-200 bg-white px-3 text-slate-600 transition hover:border-blue-300 hover:text-blue-600"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2">
            <circle cx="12" cy="12" r="3"/>
            <path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
            <circle cx="12" cy="12" r="9" strokeDasharray="4 3"/>
          </svg>
        </button>
      </div>
      {open && results.length > 0 && (
        <ul className="absolute z-[9999] mt-1 w-full max-h-64 overflow-y-auto rounded-2xl border border-slate-200 bg-white shadow-xl shadow-slate-200/80">
          {results.map((r) => (
            <li key={r.place_id}>
              <button
                type="button"
                className="flex w-full items-start gap-3 px-4 py-3 text-left text-sm hover:bg-blue-50 transition"
                onClick={() => handleSelect(r)}
              >
                <svg viewBox="0 0 24 24" className="mt-0.5 h-4 w-4 shrink-0 fill-none stroke-blue-500" strokeWidth="2">
                  <path d="M12 22s8-6.6 8-12A8 8 0 1 0 4 10c0 5.4 8 12 8 12Z"/>
                  <circle cx="12" cy="10" r="3"/>
                </svg>
                <span className="line-clamp-2 text-slate-700">{r.display_name}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
