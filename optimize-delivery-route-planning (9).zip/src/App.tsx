import { useMemo, useState, lazy, Suspense } from "react";
import { AdminDashboard } from "./admin/AdminDashboard";
import type { StopInput, Vehicle, DriverRoute } from "./types";
import { LocationSearch } from "./components/LocationSearch";
import {
  createId,
  formatDistance,
  formatDuration,
  formatCoordinate,
  haversineKm,
  buildDriverRoutes,
  VEHICLE_COLORS,
} from "./utils/routing";

const RouteMap = lazy(() => import("./components/RouteMap").then((m) => ({ default: m.RouteMap })));

// ── demo data ────────────────────────────────────────────────────────────────
const demoDepot = { name: "LadGEO Central Hub", lat: "6.5244", lng: "3.3792" };
const demoStops: StopInput[] = [
  { id: createId(), name: "Victoria Island", lat: "6.4281", lng: "3.4219", packageWeight: "12", priority: "high" },
  { id: createId(), name: "Yaba Tech Corridor", lat: "6.5095", lng: "3.3712", packageWeight: "8", priority: "medium" },
  { id: createId(), name: "Lekki Phase 1", lat: "6.4476", lng: "3.4723", packageWeight: "20", priority: "high" },
  { id: createId(), name: "Ikeja City Mall", lat: "6.6143", lng: "3.3577", packageWeight: "15", priority: "low" },
  { id: createId(), name: "Surulere Market", lat: "6.4993", lng: "3.3537", packageWeight: "10", priority: "medium" },
  { id: createId(), name: "Apapa Logistics Yard", lat: "6.4480", lng: "3.3590", packageWeight: "30", priority: "high" },
];
const demoVehicles: Vehicle[] = [
  { id: createId(), name: "Van Alpha", capacityKg: "80", speedKmh: "38", color: "#2563eb" },
  { id: createId(), name: "Bike Beta", capacityKg: "25", speedKmh: "45", color: "#16a34a" },
];

// ── helpers ──────────────────────────────────────────────────────────────────
function createStopInput(name = "", lat = "", lng = ""): StopInput {
  return { id: createId(), name, lat, lng, packageWeight: "5", priority: "medium" };
}

function MetricCard({ label, value, hint, accent = "blue" }: {
  label: string; value: string; hint: string; accent?: "blue" | "emerald" | "violet" | "amber";
}) {
  const styles = {
    blue: "from-blue-500/15 to-cyan-400/10 ring-blue-200/70",
    emerald: "from-emerald-500/15 to-teal-400/10 ring-emerald-200/70",
    violet: "from-violet-500/15 to-fuchsia-400/10 ring-violet-200/70",
    amber: "from-amber-500/15 to-orange-400/10 ring-amber-200/70",
  };
  return (
    <div className={`rounded-3xl border border-white/70 bg-gradient-to-br p-5 shadow-lg shadow-slate-200/40 ring-1 backdrop-blur-sm ${styles[accent]}`}>
      <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">{label}</p>
      <p className="mt-3 text-3xl font-bold tracking-tight text-slate-950">{value}</p>
      <p className="mt-2 text-sm text-slate-600">{hint}</p>
    </div>
  );
}

function VehicleCard({ vehicle, index, onChange, onRemove }: {
  vehicle: Vehicle; index: number;
  onChange: (field: keyof Omit<Vehicle, "id">, value: string) => void;
  onRemove: () => void;
}) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-4 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-block h-3 w-3 rounded-full border-2 border-white shadow" style={{ background: vehicle.color }} />
          <span className="text-sm font-bold text-slate-800">Vehicle {index + 1}</span>
        </div>
        <button type="button" onClick={onRemove}
          className="rounded-full border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-500 hover:border-rose-300 hover:text-rose-600 transition">
          Remove
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Name</span>
          <input value={vehicle.name} onChange={(e) => onChange("name", e.target.value)}
            className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none focus:border-blue-400 transition"
            placeholder="Van / Bike / Truck" />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Capacity (kg)</span>
          <input value={vehicle.capacityKg} onChange={(e) => onChange("capacityKg", e.target.value)}
            type="number" min="1"
            className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none focus:border-blue-400 transition"
            placeholder="500" />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Avg Speed (km/h)</span>
          <input value={vehicle.speedKmh} onChange={(e) => onChange("speedKmh", e.target.value)}
            type="number" min="1"
            className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 outline-none focus:border-blue-400 transition"
            placeholder="40" />
        </label>
        <label className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Route Colour</span>
          <div className="flex items-center gap-2">
            <input type="color" value={vehicle.color} onChange={(e) => onChange("color", e.target.value)}
              className="h-10 w-16 rounded-xl border border-slate-200 cursor-pointer bg-white p-1" />
            <span className="text-sm text-slate-600">{vehicle.color}</span>
          </div>
        </label>
      </div>
    </div>
  );
}

// ── main App ─────────────────────────────────────────────────────────────────
export function App() {
  const [showAdmin, setShowAdmin] = useState(false);

  if (showAdmin) {
    return <AdminDashboard onBack={() => setShowAdmin(false)} />;
  }

  // Hub
  const [depotName, setDepotName] = useState(demoDepot.name);
  const [depotLat, setDepotLat] = useState(demoDepot.lat);
  const [depotLng, setDepotLng] = useState(demoDepot.lng);
  // Settings
  const [serviceMinutes, setServiceMinutes] = useState("8");
  const [returnToStart, setReturnToStart] = useState(true);
  // Stops
  const [stops, setStops] = useState<StopInput[]>(demoStops);
  // Vehicles
  const [vehicles, setVehicles] = useState<Vehicle[]>(demoVehicles);
  // Bulk
  const [bulkInput, setBulkInput] = useState(
    "Marina Client,6.4549,3.3947\nAjah Estate,6.4698,3.5852\nMaryland Pickup,6.5731,3.3731"
  );
  const [bulkMsg, setBulkMsg] = useState("");
  // UI tabs
  const [activeTab, setActiveTab] = useState<"planner" | "vehicles" | "bulk">("planner");
  const [mapKey, setMapKey] = useState(0);

  // ── derived analysis ────────────────────────────────────────────────────────
  const analysis = useMemo(() => {
    const errors: string[] = [];
    const dLat = parseFloat(depotLat), dLng = parseFloat(depotLng);

    if (!isFinite(dLat) || dLat < -90 || dLat > 90) errors.push("Hub latitude must be a valid number between -90 and 90.");
    if (!isFinite(dLng) || dLng < -180 || dLng > 180) errors.push("Hub longitude must be a valid number between -180 and 180.");

    if (errors.length) return { errors, driverRoutes: [], start: null, validStops: [], totalDistanceKm: 0, baselineDistanceKm: 0, totalMinutes: 0, baselineMinutes: 0, savedDistanceKm: 0, savedMinutes: 0 };

    const start: import("./types").Point = { id: "hub", name: depotName || "Hub", lat: dLat, lng: dLng, packageWeight: 0, priority: "medium" };

    const validStops = stops.flatMap((s) => {
      const lat = parseFloat(s.lat), lng = parseFloat(s.lng);
      const w = parseFloat(s.packageWeight);
      if (!isFinite(lat) || !isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) return [];
      return [{ id: s.id, name: s.name || `Stop`, lat, lng, packageWeight: isFinite(w) && w > 0 ? w : 1, priority: s.priority }];
    });

    if (validStops.length === 0) { errors.push("Add at least one valid destination."); return { errors, driverRoutes: [], start, validStops: [], totalDistanceKm: 0, baselineDistanceKm: 0, totalMinutes: 0, baselineMinutes: 0, savedDistanceKm: 0, savedMinutes: 0 }; }

    const svcMin = parseFloat(serviceMinutes) || 0;
    const driverRoutes = buildDriverRoutes(start, validStops, vehicles, svcMin, returnToStart);

    const totalDistanceKm = driverRoutes.reduce((s, r) => s + r.totalDistanceKm, 0);
    const totalMinutes = driverRoutes.reduce((s, r) => s + r.totalMinutes, 0);

    // Baseline: single vehicle visits all stops in input order at 40 km/h
    const baselineSpeed = 40;
    let baselineDist = 0;
    let prev = start;
    for (const stop of validStops) { baselineDist += haversineKm(prev, stop); prev = stop; }
    if (returnToStart) baselineDist += haversineKm(prev, start);
    const baselineMinutes = (baselineDist / baselineSpeed) * 60 + validStops.length * svcMin;

    return {
      errors,
      start,
      validStops,
      driverRoutes,
      totalDistanceKm,
      baselineDistanceKm: baselineDist,
      totalMinutes,
      baselineMinutes,
      savedDistanceKm: Math.max(0, baselineDist - totalDistanceKm),
      savedMinutes: Math.max(0, baselineMinutes - totalMinutes),
    };
  }, [depotLat, depotLng, depotName, serviceMinutes, returnToStart, stops, vehicles]);

  const improvementPct = analysis.baselineDistanceKm > 0
    ? Math.max(0, (analysis.savedDistanceKm / analysis.baselineDistanceKm) * 100) : 0;

  // ── stop helpers ────────────────────────────────────────────────────────────
  function updateStop(id: string, field: keyof Omit<StopInput, "id">, value: string) {
    setStops((prev) => prev.map((s) => s.id === id ? { ...s, [field]: value } : s));
  }
  function addStop() { setStops((prev) => [...prev, createStopInput()]); }
  function removeStop(id: string) { setStops((prev) => prev.filter((s) => s.id !== id)); }

  // ── vehicle helpers ─────────────────────────────────────────────────────────
  function addVehicle() {
    const colorIdx = vehicles.length % VEHICLE_COLORS.length;
    setVehicles((prev) => [...prev, { id: createId(), name: `Vehicle ${prev.length + 1}`, capacityKg: "200", speedKmh: "40", color: VEHICLE_COLORS[colorIdx] }]);
  }
  function updateVehicle(id: string, field: keyof Omit<Vehicle, "id">, value: string) {
    setVehicles((prev) => prev.map((v) => v.id === id ? { ...v, [field]: value } : v));
  }
  function removeVehicle(id: string) {
    setVehicles((prev) => prev.length > 1 ? prev.filter((v) => v.id !== id) : prev);
  }

  // ── bulk import ─────────────────────────────────────────────────────────────
  function importBulk(mode: "append" | "replace") {
    const lines = bulkInput.split("\n").map((l) => l.trim()).filter(Boolean);
    const imported: StopInput[] = [];
    let skipped = 0;
    lines.forEach((line, i) => {
      const parts = line.split(",").map((p) => p.trim()).filter(Boolean);
      if (parts.length < 2) { skipped++; return; }
      let name = "", lat = "", lng = "";
      if (parts.length === 2) { [lat, lng] = parts; name = `Stop ${i + 1}`; }
      else { name = parts.slice(0, -2).join(", "); lat = parts[parts.length - 2]; lng = parts[parts.length - 1]; }
      imported.push({ id: createId(), name, lat, lng, packageWeight: "5", priority: "medium" });
    });
    if (imported.length === 0) { setBulkMsg("No valid lines found. Use: name, lat, lng"); return; }
    setStops((prev) => mode === "replace" ? imported : [...prev, ...imported]);
    setBulkMsg(`Imported ${imported.length} stop${imported.length > 1 ? "s" : ""}${skipped ? `, skipped ${skipped} invalid` : ""}.`);
  }

  // ── load demo ───────────────────────────────────────────────────────────────
  function loadDemo() {
    setDepotName(demoDepot.name); setDepotLat(demoDepot.lat); setDepotLng(demoDepot.lng);
    setServiceMinutes("8"); setReturnToStart(true);
    setStops(demoStops.map((s) => ({ ...s, id: createId() })));
    setVehicles(demoVehicles.map((v) => ({ ...v, id: createId() })));
    setMapKey((k) => k + 1);
  }

  const tabs = [
    { key: "planner", label: "Stops & Hub" },
    { key: "vehicles", label: `Vehicles (${vehicles.length})` },
    { key: "bulk", label: "Bulk Import" },
  ] as const;

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(59,130,246,0.13),transparent_30%),radial-gradient(circle_at_bottom_right,rgba(168,85,247,0.12),transparent_30%),linear-gradient(180deg,#f8fafc_0%,#eef2ff_50%,#f8fafc_100%)] text-slate-900">
      <div className="mx-auto max-w-[1440px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">

        {/* ── Header ── */}
        <header className="overflow-hidden rounded-[2rem] border border-white/70 bg-white/80 shadow-2xl shadow-slate-200/60 backdrop-blur-xl mb-6">
          <div className="flex flex-wrap items-center justify-between gap-6 px-6 py-5 lg:px-10">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg">
                <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-current" strokeWidth="2">
                  <path d="M12 22s8-6.6 8-12A8 8 0 1 0 4 10c0 5.4 8 12 8 12Z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-black tracking-tight text-slate-950">LadGEO</h1>
                <p className="text-sm text-slate-500">Multi-stop delivery route intelligence</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex gap-2 rounded-2xl border border-slate-200 bg-slate-50 p-1.5">
                {[
                  { label: `${analysis.validStops?.length ?? 0} stops`, color: "text-blue-700 bg-blue-50" },
                  { label: `${vehicles.length} vehicle${vehicles.length > 1 ? "s" : ""}`, color: "text-violet-700 bg-violet-50" },
                  { label: `${improvementPct.toFixed(1)}% saved`, color: "text-emerald-700 bg-emerald-50" },
                ].map((badge) => (
                  <span key={badge.label} className={`rounded-xl px-3 py-1.5 text-xs font-bold ${badge.color}`}>{badge.label}</span>
                ))}
              </div>
              <button onClick={() => setShowAdmin(true)}
                className="rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700 transition flex items-center gap-2">
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                Admin
              </button>
              <button onClick={loadDemo} className="rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-blue-300 hover:text-blue-700 transition">
                Load demo
              </button>
              <button onClick={() => { setStops([]); setBulkMsg(""); }}
                className="rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-rose-300 hover:text-rose-700 transition">
                Clear
              </button>
            </div>
          </div>
          {/* summary strip */}
          <div className="border-t border-slate-100 bg-slate-50/60 px-6 lg:px-10">
            <div className="flex flex-wrap gap-6 py-3 text-sm">
              {[
                { label: "Optimized distance", value: formatDistance(analysis.totalDistanceKm) },
                { label: "Total route time", value: formatDuration(analysis.totalMinutes) },
                { label: "Distance saved", value: formatDistance(analysis.savedDistanceKm), green: true },
                { label: "vs baseline", value: formatDuration(analysis.baselineMinutes) },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2">
                  <span className="text-slate-500">{item.label}:</span>
                  <span className={`font-bold ${item.green ? "text-emerald-600" : "text-slate-900"}`}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </header>

        {/* ── Two-col layout ── */}
        <div className="grid gap-6 xl:grid-cols-[480px,1fr]">

          {/* LEFT PANEL */}
          <div className="space-y-4">

            {/* Tab bar */}
            <div className="flex rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm gap-1">
              {tabs.map((t) => (
                <button key={t.key} onClick={() => setActiveTab(t.key)}
                  className={`flex-1 rounded-xl px-3 py-2 text-sm font-semibold transition ${activeTab === t.key ? "bg-slate-950 text-white shadow" : "text-slate-600 hover:bg-slate-100"}`}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* ── TAB: Stops & Hub ── */}
            {activeTab === "planner" && (
              <div className="space-y-4 rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
                {/* Hub */}
                <div>
                  <h2 className="text-lg font-bold text-slate-950 mb-3">Dispatch Hub</h2>
                  <div className="space-y-3 rounded-3xl border border-slate-200 bg-slate-50/80 p-4">
                    <LocationSearch
                      label="Search hub location"
                      placeholder="Search city, address, landmark…"
                      defaultValue={depotName}
                      onSelect={(name, lat, lng) => { setDepotName(name); setDepotLat(lat); setDepotLng(lng); setMapKey((k) => k + 1); }}
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <label className="space-y-1.5">
                        <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Latitude</span>
                        <input value={depotLat} onChange={(e) => setDepotLat(e.target.value)} type="number" step="0.0001"
                          className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" placeholder="6.5244" />
                      </label>
                      <label className="space-y-1.5">
                        <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Longitude</span>
                        <input value={depotLng} onChange={(e) => setDepotLng(e.target.value)} type="number" step="0.0001"
                          className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" placeholder="3.3792" />
                      </label>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="space-y-1.5">
                        <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Service time/stop (min)</span>
                        <input value={serviceMinutes} onChange={(e) => setServiceMinutes(e.target.value)} type="number" min="0"
                          className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
                      </label>
                      <label className="flex items-end rounded-2xl border border-slate-200 bg-white px-3 py-2.5 gap-3">
                        <div className="flex-1">
                          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Return to hub</p>
                          <p className="text-xs text-slate-400 mt-0.5">Close loop</p>
                        </div>
                        <button type="button" onClick={() => setReturnToStart((v) => !v)}
                          className={`relative inline-flex h-6 w-12 items-center rounded-full transition ${returnToStart ? "bg-blue-600" : "bg-slate-300"}`}>
                          <span className={`inline-block h-4 w-4 rounded-full bg-white transition ${returnToStart ? "translate-x-7" : "translate-x-1"}`} />
                        </button>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Stops */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-lg font-bold text-slate-950">Destinations</h2>
                    <button onClick={addStop}
                      className="rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 transition">
                      + Add stop
                    </button>
                  </div>

                  {stops.length === 0 ? (
                    <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50/80 py-10 text-center text-sm text-slate-500">
                      No destinations yet. Add stops or import in bulk.
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
                      {stops.map((stop, idx) => (
                        <div key={stop.id} className="rounded-3xl border border-slate-200 bg-white p-4 space-y-3">
                          <div className="flex items-center justify-between gap-2">
                            <span className="inline-flex h-7 w-7 items-center justify-center rounded-xl bg-slate-950 text-xs font-bold text-white">{idx + 1}</span>
                            <div className="flex gap-2 ml-auto">
                              <select value={stop.priority} onChange={(e) => updateStop(stop.id, "priority", e.target.value as "high" | "medium" | "low")}
                                className="rounded-xl border border-slate-200 bg-slate-50 px-2 py-1.5 text-xs font-semibold text-slate-700 outline-none focus:border-blue-400">
                                <option value="high">🔴 High</option>
                                <option value="medium">🟡 Medium</option>
                                <option value="low">🟢 Low</option>
                              </select>
                              <button onClick={() => removeStop(stop.id)}
                                className="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-500 hover:border-rose-300 hover:text-rose-600 transition">
                                ✕
                              </button>
                            </div>
                          </div>
                          <LocationSearch
                            placeholder="Search stop location…"
                            defaultValue={stop.name}
                            onSelect={(name, lat, lng) => {
                              updateStop(stop.id, "name", name);
                              updateStop(stop.id, "lat", lat);
                              updateStop(stop.id, "lng", lng);
                              setMapKey((k) => k + 1);
                            }}
                          />
                          <div className="grid grid-cols-3 gap-2">
                            <label className="space-y-1">
                              <span className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Lat</span>
                              <input value={stop.lat} onChange={(e) => updateStop(stop.id, "lat", e.target.value)} type="number" step="0.0001"
                                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs outline-none focus:border-blue-400 transition" placeholder="6.4281" />
                            </label>
                            <label className="space-y-1">
                              <span className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Lng</span>
                              <input value={stop.lng} onChange={(e) => updateStop(stop.id, "lng", e.target.value)} type="number" step="0.0001"
                                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs outline-none focus:border-blue-400 transition" placeholder="3.4219" />
                            </label>
                            <label className="space-y-1">
                              <span className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Weight kg</span>
                              <input value={stop.packageWeight} onChange={(e) => updateStop(stop.id, "packageWeight", e.target.value)} type="number" min="0"
                                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs outline-none focus:border-blue-400 transition" placeholder="5" />
                            </label>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── TAB: Vehicles ── */}
            {activeTab === "vehicles" && (
              <div className="space-y-4 rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-bold text-slate-950">Fleet Configuration</h2>
                    <p className="text-sm text-slate-500 mt-0.5">Each vehicle gets an optimized sub-route based on capacity.</p>
                  </div>
                  <button onClick={addVehicle}
                    className="rounded-full bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700 transition">
                    + Add vehicle
                  </button>
                </div>
                <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
                  {vehicles.map((v, i) => (
                    <VehicleCard key={v.id} vehicle={v} index={i}
                      onChange={(field, val) => updateVehicle(v.id, field, val)}
                      onRemove={() => removeVehicle(v.id)} />
                  ))}
                </div>
                <div className="rounded-2xl border border-violet-100 bg-violet-50/60 p-4 text-sm text-violet-900 leading-6">
                  <b>Multi-driver logic:</b> Stops are assigned to vehicles using capacity-aware bin packing. High-priority stops are assigned first. Each vehicle's route is independently optimized.
                </div>
              </div>
            )}

            {/* ── TAB: Bulk Import ── */}
            {activeTab === "bulk" && (
              <div className="space-y-4 rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
                <div>
                  <h2 className="text-lg font-bold text-slate-950">Bulk Coordinate Import</h2>
                  <p className="text-sm text-slate-500 mt-0.5">One stop per line: <code className="bg-slate-100 px-1 rounded text-xs">name, lat, lng</code> or <code className="bg-slate-100 px-1 rounded text-xs">lat, lng</code></p>
                </div>
                <textarea value={bulkInput} onChange={(e) => setBulkInput(e.target.value)}
                  className="min-h-44 w-full rounded-3xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm text-slate-900 outline-none focus:border-blue-400 transition font-mono"
                  placeholder={"Customer A, 6.4281, 3.4219\nWarehouse B, 6.5095, 3.3712"} />
                <div className="flex flex-wrap gap-3 items-center">
                  <button onClick={() => importBulk("append")}
                    className="rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 transition">
                    Append stops
                  </button>
                  <button onClick={() => importBulk("replace")}
                    className="rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-violet-300 hover:text-violet-700 transition">
                    Replace list
                  </button>
                  {bulkMsg && <p className="text-sm text-slate-500">{bulkMsg}</p>}
                </div>
              </div>
            )}

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <MetricCard label="Optimized distance" value={formatDistance(analysis.totalDistanceKm)} hint="Total km across all vehicles." accent="blue" />
              <MetricCard label="Total time" value={formatDuration(analysis.totalMinutes)} hint="Drive + service for all routes." accent="violet" />
              <MetricCard label="Distance saved" value={formatDistance(analysis.savedDistanceKm)} hint="vs single-vehicle baseline order." accent="emerald" />
              <MetricCard label="Baseline time" value={formatDuration(analysis.baselineMinutes)} hint="Manual single-vehicle estimate." accent="amber" />
            </div>

            {/* Errors */}
            {analysis.errors.length > 0 && (
              <div className="rounded-[2rem] border border-amber-200 bg-amber-50/90 p-5 shadow-lg shadow-amber-100/50">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-full bg-amber-500/15 p-2 text-amber-700">
                    <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2">
                      <path d="M12 9v4"/><path d="M12 17h.01"/>
                      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/>
                    </svg>
                  </div>
                  <ul className="space-y-1 text-sm text-amber-900">
                    {analysis.errors.map((e) => <li key={e}>• {e}</li>)}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT PANEL */}
          <div className="space-y-6">

            {/* Map */}
            <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-2xl shadow-slate-200/50 backdrop-blur-xl">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-950">Live Route Map</h2>
                  <p className="text-sm text-slate-500 mt-0.5">Real road paths via OpenStreetMap & OSRM routing engine.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {(analysis.driverRoutes ?? []).map((r: DriverRoute) => (
                    <span key={r.vehicle.id} className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-sm">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: r.vehicle.color }} />
                      {r.vehicle.name} · {r.stops.length} stops · {formatDistance(r.totalDistanceKm)}
                    </span>
                  ))}
                </div>
              </div>
              {analysis.start && (analysis.driverRoutes ?? []).length > 0 ? (
                <Suspense fallback={
                  <div className="h-[520px] flex items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-slate-50 text-slate-500 text-sm">
                    Loading map…
                  </div>
                }>
                  <RouteMap
                    key={mapKey}
                    start={analysis.start}
                    driverRoutes={analysis.driverRoutes}
                    returnToStart={returnToStart}
                  />
                </Suspense>
              ) : (
                <div className="h-[520px] flex items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-slate-50 text-slate-500 text-sm">
                  Add valid coordinates to display the route map.
                </div>
              )}
            </div>

            {/* Per-vehicle route breakdown */}
            {(analysis.driverRoutes ?? []).length > 0 && (
              <div className="space-y-4">
                {(analysis.driverRoutes as DriverRoute[]).map((route, ri) => (
                  <div key={route.vehicle.id} className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
                    <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-3">
                        <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl font-bold text-white text-sm shadow"
                          style={{ background: route.vehicle.color }}>{ri + 1}</span>
                        <div>
                          <h3 className="text-lg font-bold text-slate-950">{route.vehicle.name}</h3>
                          <p className="text-sm text-slate-500">{route.stops.length} stops · {formatDistance(route.totalDistanceKm)} · {formatDuration(route.totalMinutes)}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600">
                          📦 {route.totalWeightKg.toFixed(1)} kg / {parseFloat(route.vehicle.capacityKg) || "∞"} kg
                        </span>
                        <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600">
                          🚗 {route.vehicle.speedKmh} km/h
                        </span>
                      </div>
                    </div>

                    {/* Capacity bar */}
                    {parseFloat(route.vehicle.capacityKg) > 0 && (
                      <div className="mb-4">
                        <div className="flex justify-between text-xs text-slate-500 mb-1">
                          <span>Capacity utilisation</span>
                          <span>{Math.min(100, (route.totalWeightKg / (parseFloat(route.vehicle.capacityKg) || 1) * 100)).toFixed(1)}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-slate-200 overflow-hidden">
                          <div className="h-full rounded-full transition-all"
                            style={{ width: `${Math.min(100, route.totalWeightKg / (parseFloat(route.vehicle.capacityKg) || 1) * 100)}%`, background: route.vehicle.color }} />
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      {route.stops.map((stop, si) => {
                        const seg = route.segments[si];
                        const priorityIcon = stop.priority === "high" ? "🔴" : stop.priority === "medium" ? "🟡" : "🟢";
                        return (
                          <div key={stop.id} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-xs font-bold text-white shadow-sm"
                              style={{ background: route.vehicle.color }}>{si + 1}</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-900 truncate">{priorityIcon} {stop.name}</p>
                              <p className="text-xs text-slate-500">{formatCoordinate(stop.lat)}, {formatCoordinate(stop.lng)} · {stop.packageWeight} kg</p>
                            </div>
                            <div className="shrink-0 text-right">
                              <p className="text-xs font-semibold text-slate-700">{formatDistance(seg?.distanceKm ?? 0)}</p>
                              <p className="text-xs text-blue-600 font-bold">ETA +{formatDuration(seg?.etaMinutes ?? 0)}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {returnToStart && route.stops.length > 0 && (
                      <div className="mt-2 rounded-2xl border border-dashed border-slate-200 px-4 py-2.5 text-sm text-slate-500 flex items-center justify-between">
                        <span>↩ Return to hub: {route.vehicle.name}</span>
                        <span className="font-semibold text-slate-700">{formatDistance(haversineKm(route.stops[route.stops.length - 1], analysis.start!))}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <footer className="mt-10 text-center text-xs text-slate-400">
          LadGEO © {new Date().getFullYear()} · Map data © OpenStreetMap contributors · Routing by OSRM
        </footer>
      </div>
    </div>
  );
}
