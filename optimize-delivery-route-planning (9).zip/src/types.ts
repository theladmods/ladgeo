export type StopInput = {
  id: string;
  name: string;
  lat: string;
  lng: string;
  packageWeight: string; // kg
  priority: "high" | "medium" | "low";
};

export type Point = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  packageWeight: number;
  priority: "high" | "medium" | "low";
};

export type Vehicle = {
  id: string;
  name: string;
  capacityKg: string;
  speedKmh: string;
  color: string;
};

export type Segment = {
  from: string;
  to: string;
  distanceKm: number;
  driveMinutes: number;
  etaMinutes: number;
};

export type DriverRoute = {
  vehicle: Vehicle;
  stops: Point[];
  segments: Segment[];
  totalDistanceKm: number;
  totalDriveMinutes: number;
  totalServiceMinutes: number;
  totalMinutes: number;
  totalWeightKg: number;
};

export type AnalysisResult = {
  start: Point;
  validStops: Point[];
  driverRoutes: DriverRoute[];
  totalDistanceKm: number;
  baselineDistanceKm: number;
  totalDriveMinutes: number;
  totalServiceMinutes: number;
  totalMinutes: number;
  baselineMinutes: number;
  savedDistanceKm: number;
  savedMinutes: number;
  mode: "exact" | "heuristic";
  errors: string[];
};

export type NominatimResult = {
  place_id: number;
  display_name: string;
  lat: string;
  lon: string;
  type: string;
};

// ── Admin types ──────────────────────────────────────────────────────────────

export type Driver = {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: "active" | "inactive" | "on_route" | "offline";
  vehicle: string;
  completedDeliveries: number;
  rating: number;
  joinDate: string;
  avatar: string;
};

export type DeliveryOrder = {
  id: string;
  trackingCode: string;
  customer: string;
  destination: string;
  lat: string;
  lng: string;
  weight: string;
  priority: "high" | "medium" | "low";
  status: "pending" | "assigned" | "in_transit" | "delivered" | "failed";
  assignedDriver: string;
  createdAt: string;
  deliveredAt?: string;
  notes: string;
};

export type FleetVehicle = {
  id: string;
  name: string;
  plate: string;
  type: "van" | "bike" | "truck" | "car";
  capacityKg: string;
  status: "available" | "in_use" | "maintenance" | "retired";
  driver: string;
  fuelLevel: number;
  lastService: string;
  totalTrips: number;
  color: string;
};

export type SystemSetting = {
  id: string;
  key: string;
  label: string;
  value: string;
  type: "text" | "number" | "toggle" | "select";
  options?: string[];
  group: string;
};

export type AdminPage =
  | "dashboard"
  | "orders"
  | "drivers"
  | "fleet"
  | "analytics"
  | "settings";

