import { useState, useMemo } from "react";
import type { Driver, DeliveryOrder, FleetVehicle, SystemSetting, AdminPage } from "../types";
import { createId } from "../utils/routing";

// ── Seed data ──────────────────────────────────────────────────────────────

const seedDrivers: Driver[] = [
  { id: createId(), name: "Adewale Okafor", email: "adewale@ladgeo.ng", phone: "+234 801 234 5678", status: "on_route", vehicle: "Van Alpha", completedDeliveries: 248, rating: 4.9, joinDate: "2023-01-15", avatar: "AO" },
  { id: createId(), name: "Chioma Nwosu", email: "chioma@ladgeo.ng", phone: "+234 802 345 6789", status: "active", vehicle: "Bike Beta", completedDeliveries: 185, rating: 4.7, joinDate: "2023-03-22", avatar: "CN" },
  { id: createId(), name: "Emeka Dike", email: "emeka@ladgeo.ng", phone: "+234 803 456 7890", status: "offline", vehicle: "Truck Gamma", completedDeliveries: 312, rating: 4.8, joinDate: "2022-11-10", avatar: "ED" },
  { id: createId(), name: "Fatima Bello", email: "fatima@ladgeo.ng", phone: "+234 804 567 8901", status: "active", vehicle: "Van Delta", completedDeliveries: 97, rating: 4.6, joinDate: "2024-01-08", avatar: "FB" },
  { id: createId(), name: "Gbenga Afolabi", email: "gbenga@ladgeo.ng", phone: "+234 805 678 9012", status: "inactive", vehicle: "Car Epsilon", completedDeliveries: 54, rating: 4.3, joinDate: "2024-03-19", avatar: "GA" },
  { id: createId(), name: "Halima Yusuf", email: "halima@ladgeo.ng", phone: "+234 806 789 0123", status: "on_route", vehicle: "Bike Zeta", completedDeliveries: 201, rating: 4.9, joinDate: "2023-07-04", avatar: "HY" },
];

const seedOrders: DeliveryOrder[] = [
  { id: createId(), trackingCode: "LGO-20240001", customer: "TechStore Lagos", destination: "Victoria Island", lat: "6.4281", lng: "3.4219", weight: "12", priority: "high", status: "in_transit", assignedDriver: "Adewale Okafor", createdAt: "2024-07-01T09:00:00", notes: "Handle with care" },
  { id: createId(), trackingCode: "LGO-20240002", customer: "Mama Cee Boutique", destination: "Yaba Market", lat: "6.5095", lng: "3.3712", weight: "8", priority: "medium", status: "delivered", assignedDriver: "Chioma Nwosu", createdAt: "2024-07-01T08:30:00", deliveredAt: "2024-07-01T10:15:00", notes: "" },
  { id: createId(), trackingCode: "LGO-20240003", customer: "Prime Electronics", destination: "Lekki Phase 1", lat: "6.4476", lng: "3.4723", weight: "20", priority: "high", status: "pending", assignedDriver: "", createdAt: "2024-07-01T10:00:00", notes: "Requires signature" },
  { id: createId(), trackingCode: "LGO-20240004", customer: "Global Foods Inc.", destination: "Ikeja City Mall", lat: "6.6143", lng: "3.3577", weight: "35", priority: "low", status: "assigned", assignedDriver: "Halima Yusuf", createdAt: "2024-07-01T07:45:00", notes: "" },
  { id: createId(), trackingCode: "LGO-20240005", customer: "Eko Fashion Hub", destination: "Surulere", lat: "6.4993", lng: "3.3537", weight: "5", priority: "medium", status: "delivered", assignedDriver: "Fatima Bello", createdAt: "2024-06-30T14:00:00", deliveredAt: "2024-06-30T16:30:00", notes: "" },
  { id: createId(), trackingCode: "LGO-20240006", customer: "Lagos Pharma Ltd", destination: "Apapa", lat: "6.4480", lng: "3.3590", weight: "15", priority: "high", status: "failed", assignedDriver: "Emeka Dike", createdAt: "2024-06-30T11:00:00", notes: "Customer unavailable" },
  { id: createId(), trackingCode: "LGO-20240007", customer: "Sunrise Bakery", destination: "Maryland", lat: "6.5731", lng: "3.3731", weight: "7", priority: "medium", status: "pending", assignedDriver: "", createdAt: "2024-07-01T11:30:00", notes: "" },
  { id: createId(), trackingCode: "LGO-20240008", customer: "Delta Supermart", destination: "Ajah", lat: "6.4698", lng: "3.5852", weight: "42", priority: "low", status: "in_transit", assignedDriver: "Adewale Okafor", createdAt: "2024-07-01T09:45:00", notes: "Bulk order" },
];

const seedFleet: FleetVehicle[] = [
  { id: createId(), name: "Van Alpha", plate: "LND-001-AA", type: "van", capacityKg: "800", status: "in_use", driver: "Adewale Okafor", fuelLevel: 68, lastService: "2024-06-15", totalTrips: 412, color: "#2563eb" },
  { id: createId(), name: "Bike Beta", plate: "LND-002-BB", type: "bike", capacityKg: "30", status: "available", driver: "Chioma Nwosu", fuelLevel: 90, lastService: "2024-06-28", totalTrips: 289, color: "#16a34a" },
  { id: createId(), name: "Truck Gamma", plate: "LND-003-CC", type: "truck", capacityKg: "3000", status: "maintenance", driver: "Emeka Dike", fuelLevel: 45, lastService: "2024-05-30", totalTrips: 158, color: "#dc2626" },
  { id: createId(), name: "Van Delta", plate: "LND-004-DD", type: "van", capacityKg: "800", status: "available", driver: "Fatima Bello", fuelLevel: 55, lastService: "2024-06-20", totalTrips: 201, color: "#9333ea" },
  { id: createId(), name: "Car Epsilon", plate: "LND-005-EE", type: "car", capacityKg: "120", status: "available", driver: "Gbenga Afolabi", fuelLevel: 30, lastService: "2024-06-10", totalTrips: 87, color: "#ea580c" },
  { id: createId(), name: "Bike Zeta", plate: "LND-006-FF", type: "bike", capacityKg: "30", status: "in_use", driver: "Halima Yusuf", fuelLevel: 80, lastService: "2024-07-01", totalTrips: 345, color: "#0891b2" },
];

const seedSettings: SystemSetting[] = [
  { id: createId(), key: "company_name", label: "Company Name", value: "LadGEO Logistics", type: "text", group: "General" },
  { id: createId(), key: "hub_address", label: "Default Hub Address", value: "LadGEO Central Hub, Lagos", type: "text", group: "General" },
  { id: createId(), key: "default_service_time", label: "Default Service Time (min)", value: "8", type: "number", group: "Routing" },
  { id: createId(), key: "return_to_hub", label: "Return to Hub by Default", value: "true", type: "toggle", group: "Routing" },
  { id: createId(), key: "default_speed", label: "Default Vehicle Speed (km/h)", value: "40", type: "number", group: "Routing" },
  { id: createId(), key: "optimization_mode", label: "Optimization Mode", value: "balanced", type: "select", options: ["fastest", "balanced", "fuel_efficient"], group: "Routing" },
  { id: createId(), key: "notifications_email", label: "Email Notifications", value: "true", type: "toggle", group: "Notifications" },
  { id: createId(), key: "notifications_sms", label: "SMS Notifications", value: "false", type: "toggle", group: "Notifications" },
  { id: createId(), key: "alert_delay_threshold", label: "Delay Alert Threshold (min)", value: "15", type: "number", group: "Notifications" },
  { id: createId(), key: "max_vehicles", label: "Max Vehicles per Route", value: "10", type: "number", group: "Advanced" },
  { id: createId(), key: "api_key", label: "OSRM API Endpoint", value: "https://router.project-osrm.org", type: "text", group: "Advanced" },
  { id: createId(), key: "dark_mode", label: "Dark Mode", value: "false", type: "toggle", group: "Appearance" },
];

// ── Sub-components ─────────────────────────────────────────────────────────

function StatCard({ label, value, delta, icon, color }: { label: string; value: string | number; delta?: string; icon: React.ReactNode; color: string }) {
  return (
    <div className={`rounded-3xl border border-white/70 bg-white/80 p-5 shadow-lg shadow-slate-200/40 backdrop-blur-sm`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">{label}</p>
          <p className="mt-2 text-3xl font-black tracking-tight text-slate-950">{value}</p>
          {delta && <p className={`mt-1.5 text-xs font-semibold ${delta.startsWith("+") ? "text-emerald-600" : "text-rose-500"}`}>{delta} vs last week</p>}
        </div>
        <div className={`flex h-11 w-11 items-center justify-center rounded-2xl ${color}`}>{icon}</div>
      </div>
    </div>
  );
}

function Badge({ status }: { status: string }) {
  const map: Record<string, string> = {
    active: "bg-emerald-100 text-emerald-700",
    on_route: "bg-blue-100 text-blue-700",
    offline: "bg-slate-100 text-slate-500",
    inactive: "bg-amber-100 text-amber-700",
    pending: "bg-amber-100 text-amber-700",
    assigned: "bg-blue-100 text-blue-700",
    in_transit: "bg-violet-100 text-violet-700",
    delivered: "bg-emerald-100 text-emerald-700",
    failed: "bg-rose-100 text-rose-600",
    available: "bg-emerald-100 text-emerald-700",
    in_use: "bg-blue-100 text-blue-700",
    maintenance: "bg-amber-100 text-amber-700",
    retired: "bg-slate-100 text-slate-400",
  };
  const label: Record<string, string> = {
    on_route: "On Route", in_transit: "In Transit", in_use: "In Use",
  };
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold capitalize ${map[status] ?? "bg-slate-100 text-slate-600"}`}>
      {label[status] ?? status}
    </span>
  );
}

function Avatar({ initials, color }: { initials: string; color?: string }) {
  return (
    <span className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-xs font-bold text-white shadow ${color ?? "bg-slate-700"}`}>
      {initials}
    </span>
  );
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
      <div>
        <h2 className="text-xl font-black text-slate-950">{title}</h2>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

// ── Page: Dashboard ────────────────────────────────────────────────────────
function PageDashboard({ orders, drivers, fleet }: { orders: DeliveryOrder[]; drivers: Driver[]; fleet: FleetVehicle[] }) {
  const totalOrders = orders.length;
  const delivered = orders.filter((o) => o.status === "delivered").length;
  const inTransit = orders.filter((o) => o.status === "in_transit").length;
  const pending = orders.filter((o) => o.status === "pending").length;
  const activeDrivers = drivers.filter((d) => d.status === "active" || d.status === "on_route").length;
  const availableVehicles = fleet.filter((v) => v.status === "available").length;
  const deliveryRate = totalOrders > 0 ? ((delivered / totalOrders) * 100).toFixed(1) : "0";

  const recentOrders = [...orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);

  const priorityCounts = { high: 0, medium: 0, low: 0 };
  orders.forEach((o) => priorityCounts[o.priority]++);

  const statusCounts = { pending: 0, assigned: 0, in_transit: 0, delivered: 0, failed: 0 };
  orders.forEach((o) => { if (o.status in statusCounts) statusCounts[o.status as keyof typeof statusCounts]++; });

  return (
    <div className="space-y-6">
      {/* KPI cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total Orders" value={totalOrders} delta="+12%" icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-blue-600" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="m2 7 10 6 10-6"/></svg>} color="bg-blue-50" />
        <StatCard label="Delivered" value={delivered} delta="+8%" icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-emerald-600" strokeWidth="2"><path d="M20 6 9 17l-5-5"/></svg>} color="bg-emerald-50" />
        <StatCard label="In Transit" value={inTransit} icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-violet-600" strokeWidth="2"><path d="M5 17H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v3"/><rect x="9" y="11" width="14" height="10" rx="1"/><circle cx="12" cy="21" r="1"/><circle cx="20" cy="21" r="1"/></svg>} color="bg-violet-50" />
        <StatCard label="Delivery Rate" value={`${deliveryRate}%`} delta="+2.3%" icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-amber-600" strokeWidth="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>} color="bg-amber-50" />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Recent orders */}
        <div className="xl:col-span-2 rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <SectionHeader title="Recent Orders" subtitle="Latest 5 delivery requests" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wider text-slate-400">
                  <th className="pb-3 pr-4 font-semibold">Tracking</th>
                  <th className="pb-3 pr-4 font-semibold">Customer</th>
                  <th className="pb-3 pr-4 font-semibold">Destination</th>
                  <th className="pb-3 pr-4 font-semibold">Priority</th>
                  <th className="pb-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {recentOrders.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 pr-4 font-mono text-xs font-bold text-blue-600">{o.trackingCode}</td>
                    <td className="py-3 pr-4 font-medium text-slate-900 whitespace-nowrap">{o.customer}</td>
                    <td className="py-3 pr-4 text-slate-500 whitespace-nowrap">{o.destination}</td>
                    <td className="py-3 pr-4"><Badge status={o.priority} /></td>
                    <td className="py-3"><Badge status={o.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Status breakdown */}
        <div className="space-y-4">
          <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
            <SectionHeader title="Order Status" subtitle="Current breakdown" />
            <div className="space-y-3">
              {(Object.entries(statusCounts) as [string, number][]).map(([status, count]) => {
                const pct = totalOrders > 0 ? (count / totalOrders) * 100 : 0;
                const colors: Record<string, string> = { pending: "bg-amber-400", assigned: "bg-blue-400", in_transit: "bg-violet-500", delivered: "bg-emerald-500", failed: "bg-rose-400" };
                return (
                  <div key={status}>
                    <div className="flex justify-between text-xs text-slate-600 mb-1">
                      <span className="capitalize font-semibold">{status.replace("_", " ")}</span>
                      <span className="font-bold">{count} <span className="text-slate-400">({pct.toFixed(0)}%)</span></span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div className={`h-full rounded-full transition-all ${colors[status]}`} style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
            <SectionHeader title="Fleet Snapshot" />
            <div className="space-y-2">
              {[
                { label: "Active Drivers", value: activeDrivers, total: drivers.length, color: "bg-blue-500" },
                { label: "Available Vehicles", value: availableVehicles, total: fleet.length, color: "bg-emerald-500" },
                { label: "Pending Orders", value: pending, total: totalOrders, color: "bg-amber-400" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className={`h-2.5 w-2.5 rounded-full ${item.color}`} />
                    <span className="text-sm font-semibold text-slate-700">{item.label}</span>
                  </div>
                  <span className="text-sm font-black text-slate-900">{item.value} <span className="text-slate-400 font-normal">/ {item.total}</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Top drivers */}
      <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
        <SectionHeader title="Top Drivers" subtitle="Ranked by completed deliveries" />
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {[...drivers].sort((a, b) => b.completedDeliveries - a.completedDeliveries).slice(0, 6).map((d, i) => (
            <div key={d.id} className="flex items-center gap-3 rounded-2xl border border-slate-100 bg-slate-50 px-4 py-3">
              <span className="text-lg font-black text-slate-300 w-6">#{i + 1}</span>
              <Avatar initials={d.avatar} color={["bg-blue-600","bg-emerald-600","bg-violet-600","bg-amber-600","bg-rose-600","bg-cyan-600"][i]} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 truncate">{d.name}</p>
                <p className="text-xs text-slate-500">{d.completedDeliveries} deliveries · ⭐ {d.rating}</p>
              </div>
              <Badge status={d.status} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Page: Orders ───────────────────────────────────────────────────────────
function PageOrders({ orders, setOrders, drivers }: { orders: DeliveryOrder[]; setOrders: React.Dispatch<React.SetStateAction<DeliveryOrder[]>>; drivers: Driver[] }) {
  const [filter, setFilter] = useState<"all" | DeliveryOrder["status"]>("all");
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<DeliveryOrder | null>(null);
  const [form, setForm] = useState<Omit<DeliveryOrder, "id">>({ trackingCode: "", customer: "", destination: "", lat: "", lng: "", weight: "", priority: "medium", status: "pending", assignedDriver: "", createdAt: new Date().toISOString(), notes: "" });

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      const matchFilter = filter === "all" || o.status === filter;
      const matchSearch = search === "" || o.customer.toLowerCase().includes(search.toLowerCase()) || o.trackingCode.toLowerCase().includes(search.toLowerCase()) || o.destination.toLowerCase().includes(search.toLowerCase());
      return matchFilter && matchSearch;
    });
  }, [orders, filter, search]);

  function openNew() {
    setEditing(null);
    setForm({ trackingCode: `LGO-${Date.now().toString().slice(-7)}`, customer: "", destination: "", lat: "", lng: "", weight: "5", priority: "medium", status: "pending", assignedDriver: "", createdAt: new Date().toISOString(), notes: "" });
    setShowForm(true);
  }
  function openEdit(o: DeliveryOrder) { setEditing(o); setForm({ ...o }); setShowForm(true); }
  function saveOrder() {
    if (!form.customer || !form.destination) return;
    if (editing) setOrders((prev) => prev.map((o) => o.id === editing.id ? { ...form, id: editing.id } : o));
    else setOrders((prev) => [...prev, { ...form, id: createId() }]);
    setShowForm(false);
  }
  function deleteOrder(id: string) { setOrders((prev) => prev.filter((o) => o.id !== id)); }

  const statuses: Array<"all" | DeliveryOrder["status"]> = ["all", "pending", "assigned", "in_transit", "delivered", "failed"];

  return (
    <div className="space-y-5">
      <SectionHeader
        title="Delivery Orders"
        subtitle={`${filtered.length} of ${orders.length} orders`}
        action={
          <button onClick={openNew} className="rounded-full bg-slate-950 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700 transition">
            + New Order
          </button>
        }
      />

      {/* Filter + Search */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="flex gap-1 rounded-2xl border border-slate-200 bg-white p-1.5">
          {statuses.map((s) => (
            <button key={s} onClick={() => setFilter(s)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold capitalize transition ${filter === s ? "bg-slate-950 text-white shadow" : "text-slate-500 hover:bg-slate-100"}`}>
              {s}
            </button>
          ))}
        </div>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search customer, tracking, destination…"
          className="flex-1 min-w-[200px] rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm outline-none focus:border-blue-400 transition" />
      </div>

      {/* Table */}
      <div className="rounded-[2rem] border border-white/70 bg-white/80 shadow-xl shadow-slate-200/50 backdrop-blur-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/80">
              <tr className="text-left text-xs uppercase tracking-wider text-slate-400">
                <th className="px-5 py-4 font-semibold">Tracking</th>
                <th className="px-5 py-4 font-semibold">Customer</th>
                <th className="px-5 py-4 font-semibold">Destination</th>
                <th className="px-5 py-4 font-semibold">Weight</th>
                <th className="px-5 py-4 font-semibold">Priority</th>
                <th className="px-5 py-4 font-semibold">Driver</th>
                <th className="px-5 py-4 font-semibold">Status</th>
                <th className="px-5 py-4 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.length === 0 ? (
                <tr><td colSpan={8} className="py-12 text-center text-slate-400 text-sm">No orders found.</td></tr>
              ) : filtered.map((o) => (
                <tr key={o.id} className="hover:bg-slate-50/80 transition">
                  <td className="px-5 py-3.5 font-mono text-xs font-bold text-blue-600 whitespace-nowrap">{o.trackingCode}</td>
                  <td className="px-5 py-3.5 font-medium text-slate-900 whitespace-nowrap">{o.customer}</td>
                  <td className="px-5 py-3.5 text-slate-500 whitespace-nowrap">{o.destination}</td>
                  <td className="px-5 py-3.5 text-slate-700">{o.weight} kg</td>
                  <td className="px-5 py-3.5"><Badge status={o.priority} /></td>
                  <td className="px-5 py-3.5 text-slate-500 whitespace-nowrap">{o.assignedDriver || <span className="text-slate-300 italic">Unassigned</span>}</td>
                  <td className="px-5 py-3.5"><Badge status={o.status} /></td>
                  <td className="px-5 py-3.5">
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(o)} className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600 hover:border-blue-300 hover:text-blue-600 transition">Edit</button>
                      <button onClick={() => deleteOrder(o.id)} className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600 hover:border-rose-300 hover:text-rose-600 transition">Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg rounded-[2rem] border border-white/70 bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-xl font-black text-slate-950 mb-5">{editing ? "Edit Order" : "New Order"}</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {([
                ["Tracking Code", "trackingCode", "text", "LGO-XXXXXXX"],
                ["Customer Name", "customer", "text", "Customer name"],
                ["Destination", "destination", "text", "Street, City"],
                ["Latitude", "lat", "number", "6.4281"],
                ["Longitude", "lng", "number", "3.4219"],
                ["Weight (kg)", "weight", "number", "5"],
              ] as const).map(([label, key, type, placeholder]) => (
                <label key={key} className="space-y-1.5">
                  <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">{label}</span>
                  <input type={type} value={(form as Record<string, string>)[key]} placeholder={placeholder}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
                </label>
              ))}
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Priority</span>
                <select value={form.priority} onChange={(e) => setForm((f) => ({ ...f, priority: e.target.value as DeliveryOrder["priority"] }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Status</span>
                <select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value as DeliveryOrder["status"] }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="pending">Pending</option>
                  <option value="assigned">Assigned</option>
                  <option value="in_transit">In Transit</option>
                  <option value="delivered">Delivered</option>
                  <option value="failed">Failed</option>
                </select>
              </label>
              <label className="space-y-1.5 sm:col-span-2">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Assign Driver</span>
                <select value={form.assignedDriver} onChange={(e) => setForm((f) => ({ ...f, assignedDriver: e.target.value }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="">Unassigned</option>
                  {drivers.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </label>
              <label className="space-y-1.5 sm:col-span-2">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Notes</span>
                <textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} rows={2}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition resize-none" />
              </label>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={saveOrder} className="flex-1 rounded-full bg-slate-950 py-2.5 text-sm font-bold text-white hover:bg-blue-700 transition">{editing ? "Save Changes" : "Create Order"}</button>
              <button onClick={() => setShowForm(false)} className="flex-1 rounded-full border border-slate-300 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Page: Drivers ──────────────────────────────────────────────────────────
function PageDrivers({ drivers, setDrivers }: { drivers: Driver[]; setDrivers: React.Dispatch<React.SetStateAction<Driver[]>> }) {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Driver | null>(null);
  const [form, setForm] = useState<Omit<Driver, "id">>({ name: "", email: "", phone: "", status: "active", vehicle: "", completedDeliveries: 0, rating: 5.0, joinDate: new Date().toISOString().slice(0, 10), avatar: "" });

  const filtered = drivers.filter((d) => d.name.toLowerCase().includes(search.toLowerCase()) || d.email.toLowerCase().includes(search.toLowerCase()));

  function openNew() {
    setEditing(null);
    setForm({ name: "", email: "", phone: "", status: "active", vehicle: "", completedDeliveries: 0, rating: 5.0, joinDate: new Date().toISOString().slice(0, 10), avatar: "" });
    setShowForm(true);
  }
  function openEdit(d: Driver) { setEditing(d); setForm({ ...d }); setShowForm(true); }
  function save() {
    if (!form.name) return;
    const avatar = form.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
    if (editing) setDrivers((prev) => prev.map((d) => d.id === editing.id ? { ...form, avatar, id: editing.id } : d));
    else setDrivers((prev) => [...prev, { ...form, avatar, id: createId() }]);
    setShowForm(false);
  }

  const avatarColors = ["bg-blue-600", "bg-emerald-600", "bg-violet-600", "bg-amber-600", "bg-rose-600", "bg-cyan-600"];

  return (
    <div className="space-y-5">
      <SectionHeader title="Driver Management" subtitle={`${drivers.length} drivers registered`}
        action={<button onClick={openNew} className="rounded-full bg-slate-950 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700 transition">+ Add Driver</button>} />

      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or email…"
        className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm outline-none focus:border-blue-400 transition" />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.map((d, i) => (
          <div key={d.id} className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-lg shadow-slate-200/40 backdrop-blur-sm space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <Avatar initials={d.avatar} color={avatarColors[i % avatarColors.length]} />
                <div>
                  <p className="font-bold text-slate-900">{d.name}</p>
                  <p className="text-xs text-slate-500">{d.email}</p>
                </div>
              </div>
              <Badge status={d.status} />
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-xl bg-slate-50 px-3 py-2"><p className="text-slate-400">Phone</p><p className="font-semibold text-slate-700 mt-0.5">{d.phone}</p></div>
              <div className="rounded-xl bg-slate-50 px-3 py-2"><p className="text-slate-400">Vehicle</p><p className="font-semibold text-slate-700 mt-0.5">{d.vehicle || "—"}</p></div>
              <div className="rounded-xl bg-slate-50 px-3 py-2"><p className="text-slate-400">Deliveries</p><p className="font-bold text-slate-900 mt-0.5">{d.completedDeliveries}</p></div>
              <div className="rounded-xl bg-slate-50 px-3 py-2"><p className="text-slate-400">Rating</p><p className="font-bold text-amber-600 mt-0.5">⭐ {d.rating.toFixed(1)}</p></div>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={() => openEdit(d)} className="flex-1 rounded-full border border-slate-200 py-2 text-xs font-bold text-slate-600 hover:border-blue-300 hover:text-blue-600 transition">Edit</button>
              <button onClick={() => setDrivers((prev) => prev.filter((x) => x.id !== d.id))} className="flex-1 rounded-full border border-slate-200 py-2 text-xs font-bold text-slate-600 hover:border-rose-300 hover:text-rose-600 transition">Remove</button>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg rounded-[2rem] border border-white/70 bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-xl font-black text-slate-950 mb-5">{editing ? "Edit Driver" : "Add Driver"}</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {([["Full Name","name","text","John Doe"],["Email","email","email","john@ladgeo.ng"],["Phone","phone","text","+234 8XX XXX XXXX"],["Vehicle Assigned","vehicle","text","Van Alpha"]] as const).map(([label, key, type, ph]) => (
                <label key={key} className="space-y-1.5">
                  <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">{label}</span>
                  <input type={type} value={String((form as Record<string, unknown>)[key] ?? "")} placeholder={ph}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
                </label>
              ))}
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Status</span>
                <select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value as Driver["status"] }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="on_route">On Route</option>
                  <option value="offline">Offline</option>
                </select>
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Join Date</span>
                <input type="date" value={form.joinDate} onChange={(e) => setForm((f) => ({ ...f, joinDate: e.target.value }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
              </label>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={save} className="flex-1 rounded-full bg-slate-950 py-2.5 text-sm font-bold text-white hover:bg-blue-700 transition">{editing ? "Save" : "Add Driver"}</button>
              <button onClick={() => setShowForm(false)} className="flex-1 rounded-full border border-slate-300 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Page: Fleet ────────────────────────────────────────────────────────────
function PageFleet({ fleet, setFleet }: { fleet: FleetVehicle[]; setFleet: React.Dispatch<React.SetStateAction<FleetVehicle[]>> }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<FleetVehicle | null>(null);
  const [form, setForm] = useState<Omit<FleetVehicle, "id">>({ name: "", plate: "", type: "van", capacityKg: "500", status: "available", driver: "", fuelLevel: 100, lastService: new Date().toISOString().slice(0, 10), totalTrips: 0, color: "#2563eb" });

  const vehicleTypeIcons: Record<string, string> = { van: "🚐", bike: "🏍️", truck: "🚛", car: "🚗" };
  const fuelColor = (f: number) => f > 60 ? "bg-emerald-500" : f > 30 ? "bg-amber-400" : "bg-rose-500";

  function openNew() { setEditing(null); setForm({ name: "", plate: "", type: "van", capacityKg: "500", status: "available", driver: "", fuelLevel: 100, lastService: new Date().toISOString().slice(0, 10), totalTrips: 0, color: "#2563eb" }); setShowForm(true); }
  function openEdit(v: FleetVehicle) { setEditing(v); setForm({ ...v }); setShowForm(true); }
  function save() {
    if (!form.name || !form.plate) return;
    if (editing) setFleet((prev) => prev.map((v) => v.id === editing.id ? { ...form, id: editing.id } : v));
    else setFleet((prev) => [...prev, { ...form, id: createId() }]);
    setShowForm(false);
  }

  return (
    <div className="space-y-5">
      <SectionHeader title="Fleet Management" subtitle={`${fleet.length} vehicles registered`}
        action={<button onClick={openNew} className="rounded-full bg-slate-950 px-4 py-2 text-sm font-bold text-white hover:bg-blue-700 transition">+ Add Vehicle</button>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {fleet.map((v) => (
          <div key={v.id} className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-lg shadow-slate-200/40 backdrop-blur-sm space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl text-xl" style={{ background: v.color + "22" }}>{vehicleTypeIcons[v.type]}</div>
                <div>
                  <p className="font-bold text-slate-900">{v.name}</p>
                  <p className="text-xs text-slate-400 font-mono">{v.plate}</p>
                </div>
              </div>
              <Badge status={v.status} />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-500 mb-0.5">
                <span className="font-semibold">Fuel Level</span>
                <span className="font-bold" style={{ color: v.fuelLevel > 60 ? "#16a34a" : v.fuelLevel > 30 ? "#d97706" : "#dc2626" }}>{v.fuelLevel}%</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                <div className={`h-full rounded-full transition-all ${fuelColor(v.fuelLevel)}`} style={{ width: `${v.fuelLevel}%` }} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="rounded-xl bg-slate-50 px-2 py-2 text-center"><p className="text-slate-400">Capacity</p><p className="font-bold text-slate-900 mt-0.5">{v.capacityKg}kg</p></div>
              <div className="rounded-xl bg-slate-50 px-2 py-2 text-center"><p className="text-slate-400">Trips</p><p className="font-bold text-slate-900 mt-0.5">{v.totalTrips}</p></div>
              <div className="rounded-xl bg-slate-50 px-2 py-2 text-center"><p className="text-slate-400">Driver</p><p className="font-semibold text-slate-700 mt-0.5 truncate">{v.driver.split(" ")[0] || "—"}</p></div>
            </div>
            <p className="text-xs text-slate-400">Last service: {v.lastService}</p>
            <div className="flex gap-2">
              <button onClick={() => openEdit(v)} className="flex-1 rounded-full border border-slate-200 py-2 text-xs font-bold text-slate-600 hover:border-blue-300 hover:text-blue-600 transition">Edit</button>
              <button onClick={() => setFleet((prev) => prev.filter((x) => x.id !== v.id))} className="flex-1 rounded-full border border-slate-200 py-2 text-xs font-bold text-slate-600 hover:border-rose-300 hover:text-rose-600 transition">Remove</button>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-sm p-4" onClick={() => setShowForm(false)}>
          <div className="w-full max-w-lg rounded-[2rem] border border-white/70 bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-xl font-black text-slate-950 mb-5">{editing ? "Edit Vehicle" : "Add Vehicle"}</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              {([["Vehicle Name","name","text","Van Alpha"],["Plate Number","plate","text","LND-001-AA"],["Capacity (kg)","capacityKg","number","500"],["Assigned Driver","driver","text","Driver Name"]] as const).map(([label, key, type, ph]) => (
                <label key={key} className="space-y-1.5">
                  <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">{label}</span>
                  <input type={type} value={String((form as Record<string, unknown>)[key] ?? "")} placeholder={ph}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
                </label>
              ))}
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Type</span>
                <select value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as FleetVehicle["type"] }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="van">Van</option><option value="bike">Bike</option><option value="truck">Truck</option><option value="car">Car</option>
                </select>
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Status</span>
                <select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value as FleetVehicle["status"] }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition">
                  <option value="available">Available</option><option value="in_use">In Use</option><option value="maintenance">Maintenance</option><option value="retired">Retired</option>
                </select>
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Fuel Level (%)</span>
                <input type="number" min="0" max="100" value={form.fuelLevel} onChange={(e) => setForm((f) => ({ ...f, fuelLevel: Number(e.target.value) }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Last Service</span>
                <input type="date" value={form.lastService} onChange={(e) => setForm((f) => ({ ...f, lastService: e.target.value }))}
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-blue-400 transition" />
              </label>
              <label className="space-y-1.5">
                <span className="text-xs font-semibold uppercase tracking-[0.15em] text-slate-500">Route Colour</span>
                <div className="flex items-center gap-2">
                  <input type="color" value={form.color} onChange={(e) => setForm((f) => ({ ...f, color: e.target.value }))}
                    className="h-10 w-16 rounded-xl border border-slate-200 cursor-pointer bg-white p-1" />
                  <span className="text-sm text-slate-600">{form.color}</span>
                </div>
              </label>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={save} className="flex-1 rounded-full bg-slate-950 py-2.5 text-sm font-bold text-white hover:bg-blue-700 transition">{editing ? "Save" : "Add Vehicle"}</button>
              <button onClick={() => setShowForm(false)} className="flex-1 rounded-full border border-slate-300 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Page: Analytics ────────────────────────────────────────────────────────
function PageAnalytics({ orders, drivers, fleet }: { orders: DeliveryOrder[]; drivers: Driver[]; fleet: FleetVehicle[] }) {
  const delivered = orders.filter((o) => o.status === "delivered").length;
  const failed = orders.filter((o) => o.status === "failed").length;
  const totalWeight = orders.reduce((s, o) => s + (parseFloat(o.weight) || 0), 0);
  const avgRating = drivers.length > 0 ? (drivers.reduce((s, d) => s + d.rating, 0) / drivers.length).toFixed(2) : "N/A";
  const totalDeliveries = drivers.reduce((s, d) => s + d.completedDeliveries, 0);
  const inMaintenance = fleet.filter((v) => v.status === "maintenance").length;

  const weeklyData = [
    { day: "Mon", delivered: 12, failed: 1 }, { day: "Tue", delivered: 18, failed: 2 },
    { day: "Wed", delivered: 15, failed: 0 }, { day: "Thu", delivered: 22, failed: 3 },
    { day: "Fri", delivered: 27, failed: 1 }, { day: "Sat", delivered: 19, failed: 2 },
    { day: "Sun", delivered: 8, failed: 0 },
  ];
  const maxBar = Math.max(...weeklyData.map((d) => d.delivered + d.failed));

  return (
    <div className="space-y-6">
      <SectionHeader title="Analytics & Reports" subtitle="Performance overview across all operations" />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Success Rate" value={`${orders.length > 0 ? ((delivered / orders.length) * 100).toFixed(1) : 0}%`} delta="+3.2%" icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-emerald-600" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>} color="bg-emerald-50" />
        <StatCard label="Total Weight Delivered" value={`${totalWeight.toFixed(0)} kg`} icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-blue-600" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0Z"/><circle cx="12" cy="10" r="3"/></svg>} color="bg-blue-50" />
        <StatCard label="Avg Driver Rating" value={`⭐ ${avgRating}`} delta="+0.1" icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-amber-600" strokeWidth="2"><path d="M12 2 15.09 8.26 22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2Z"/></svg>} color="bg-amber-50" />
        <StatCard label="Fleet Utilization" value={`${fleet.length > 0 ? (((fleet.length - fleet.filter(v => v.status === "available").length) / fleet.length) * 100).toFixed(0) : 0}%`} icon={<svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current text-violet-600" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>} color="bg-violet-50" />
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        {/* Weekly deliveries bar chart */}
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <SectionHeader title="Weekly Deliveries" subtitle="Last 7 days performance" />
          <div className="flex items-end gap-3 h-40 mt-4">
            {weeklyData.map((d) => (
              <div key={d.day} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col justify-end rounded-xl overflow-hidden gap-0.5" style={{ height: "120px" }}>
                  <div className="w-full rounded-t-lg bg-rose-300 transition-all" style={{ height: `${(d.failed / maxBar) * 100}%` }} title={`${d.failed} failed`} />
                  <div className="w-full bg-blue-500 transition-all" style={{ height: `${(d.delivered / maxBar) * 100}%` }} title={`${d.delivered} delivered`} />
                </div>
                <span className="text-xs font-semibold text-slate-500">{d.day}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-4 mt-3">
            <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="h-2.5 w-2.5 rounded bg-blue-500" />Delivered</span>
            <span className="flex items-center gap-1.5 text-xs text-slate-500"><span className="h-2.5 w-2.5 rounded bg-rose-300" />Failed</span>
          </div>
        </div>

        {/* Driver performance table */}
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <SectionHeader title="Driver Performance" subtitle="All-time stats" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-slate-400 border-b border-slate-100">
                  <th className="pb-3 pr-4 font-semibold">Driver</th>
                  <th className="pb-3 pr-4 font-semibold">Deliveries</th>
                  <th className="pb-3 pr-4 font-semibold">Rating</th>
                  <th className="pb-3 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {[...drivers].sort((a, b) => b.completedDeliveries - a.completedDeliveries).map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-2.5 pr-4 font-semibold text-slate-900 whitespace-nowrap">{d.name}</td>
                    <td className="py-2.5 pr-4">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{d.completedDeliveries}</span>
                        <div className="h-1.5 w-16 rounded-full bg-slate-100 overflow-hidden">
                          <div className="h-full rounded-full bg-blue-500" style={{ width: `${(d.completedDeliveries / Math.max(...drivers.map(x => x.completedDeliveries))) * 100}%` }} />
                        </div>
                      </div>
                    </td>
                    <td className="py-2.5 pr-4 text-amber-600 font-bold">⭐ {d.rating}</td>
                    <td className="py-2.5"><Badge status={d.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Summary metrics */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400 mb-3">Orders Breakdown</p>
          {[
            { label: "Delivered", value: delivered, color: "bg-emerald-500" },
            { label: "Failed", value: failed, color: "bg-rose-400" },
            { label: "Pending", value: orders.filter(o => o.status === "pending").length, color: "bg-amber-400" },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
              <div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${item.color}`} /><span className="text-sm text-slate-600">{item.label}</span></div>
              <span className="text-sm font-bold text-slate-900">{item.value}</span>
            </div>
          ))}
        </div>
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400 mb-3">Fleet Health</p>
          {[
            { label: "Available", value: fleet.filter(v => v.status === "available").length, color: "bg-emerald-500" },
            { label: "In Use", value: fleet.filter(v => v.status === "in_use").length, color: "bg-blue-500" },
            { label: "Maintenance", value: inMaintenance, color: "bg-amber-400" },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
              <div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${item.color}`} /><span className="text-sm text-slate-600">{item.label}</span></div>
              <span className="text-sm font-bold text-slate-900">{item.value}</span>
            </div>
          ))}
        </div>
        <div className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400 mb-3">Key Numbers</p>
          {[
            { label: "Total Deliveries", value: totalDeliveries },
            { label: "Active Drivers", value: drivers.filter(d => d.status === "active" || d.status === "on_route").length },
            { label: "Avg Rating", value: avgRating },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
              <span className="text-sm text-slate-600">{item.label}</span>
              <span className="text-sm font-bold text-slate-900">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Page: Settings ─────────────────────────────────────────────────────────
function PageSettings({ settings, setSettings }: { settings: SystemSetting[]; setSettings: React.Dispatch<React.SetStateAction<SystemSetting[]>> }) {
  const groups = [...new Set(settings.map((s) => s.group))];
  const [saved, setSaved] = useState(false);

  function update(id: string, value: string) {
    setSettings((prev) => prev.map((s) => s.id === id ? { ...s, value } : s));
  }
  function handleSave() { setSaved(true); setTimeout(() => setSaved(false), 2500); }

  return (
    <div className="space-y-6">
      <SectionHeader title="System Settings" subtitle="Configure LadGEO platform preferences"
        action={
          <button onClick={handleSave} className={`rounded-full px-5 py-2 text-sm font-bold text-white transition ${saved ? "bg-emerald-600" : "bg-slate-950 hover:bg-blue-700"}`}>
            {saved ? "✓ Saved!" : "Save Changes"}
          </button>
        }
      />

      {groups.map((group) => (
        <div key={group} className="rounded-[2rem] border border-white/70 bg-white/80 p-5 shadow-xl shadow-slate-200/50 backdrop-blur-xl">
          <h3 className="text-base font-black text-slate-950 mb-4">{group}</h3>
          <div className="space-y-4">
            {settings.filter((s) => s.group === group).map((s) => (
              <div key={s.id} className="flex items-center justify-between gap-6 rounded-2xl border border-slate-100 bg-slate-50/80 px-4 py-3.5">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{s.label}</p>
                  <p className="text-xs text-slate-400 mt-0.5 font-mono">{s.key}</p>
                </div>
                <div className="shrink-0">
                  {s.type === "toggle" ? (
                    <button type="button" onClick={() => update(s.id, s.value === "true" ? "false" : "true")}
                      className={`relative inline-flex h-6 w-12 items-center rounded-full transition ${s.value === "true" ? "bg-blue-600" : "bg-slate-300"}`}>
                      <span className={`inline-block h-4 w-4 rounded-full bg-white transition ${s.value === "true" ? "translate-x-7" : "translate-x-1"}`} />
                    </button>
                  ) : s.type === "select" ? (
                    <select value={s.value} onChange={(e) => update(s.id, e.target.value)}
                      className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-sm outline-none focus:border-blue-400 transition capitalize">
                      {s.options?.map((o) => <option key={o} value={o}>{o.replace("_", " ")}</option>)}
                    </select>
                  ) : (
                    <input type={s.type} value={s.value} onChange={(e) => update(s.id, e.target.value)}
                      className="w-52 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-sm outline-none focus:border-blue-400 transition" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main AdminDashboard ────────────────────────────────────────────────────
export function AdminDashboard({ onBack }: { onBack: () => void }) {
  const [page, setPage] = useState<AdminPage>("dashboard");
  const [drivers, setDrivers] = useState<Driver[]>(seedDrivers);
  const [orders, setOrders] = useState<DeliveryOrder[]>(seedOrders);
  const [fleet, setFleet] = useState<FleetVehicle[]>(seedFleet);
  const [settings, setSettings] = useState<SystemSetting[]>(seedSettings);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems: Array<{ key: AdminPage; label: string; icon: React.ReactNode }> = [
    { key: "dashboard", label: "Dashboard", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg> },
    { key: "orders", label: "Orders", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/></svg> },
    { key: "drivers", label: "Drivers", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg> },
    { key: "fleet", label: "Fleet", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M5 17H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v3"/><rect x="9" y="11" width="14" height="10" rx="1"/><circle cx="12" cy="21" r="1"/><circle cx="20" cy="21" r="1"/></svg> },
    { key: "analytics", label: "Analytics", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg> },
    { key: "settings", label: "Settings", icon: <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z"/><circle cx="12" cy="12" r="3"/></svg> },
  ];

  const badgeCounts: Partial<Record<AdminPage, number>> = {
    orders: orders.filter((o) => o.status === "pending").length,
    fleet: fleet.filter((v) => v.status === "maintenance").length,
  };

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <nav className={`flex flex-col gap-1 ${mobile ? "p-4" : ""}`}>
      {navItems.map((item) => (
        <button key={item.key} onClick={() => { setPage(item.key); if (mobile) setSidebarOpen(false); }}
          className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition w-full text-left ${page === item.key ? "bg-slate-950 text-white shadow-lg" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`}>
          {item.icon}
          <span>{item.label}</span>
          {badgeCounts[item.key] ? (
            <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">
              {badgeCounts[item.key]}
            </span>
          ) : null}
        </button>
      ))}
    </nav>
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_right,rgba(168,85,247,0.1),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(59,130,246,0.1),transparent_35%),linear-gradient(180deg,#f1f5f9_0%,#e8eef7_100%)] text-slate-900">

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-slate-950/30 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)}>
          <div className="absolute left-0 top-0 bottom-0 w-72 rounded-r-[2rem] border-r border-slate-200 bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-100">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-950 text-white">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M12 22s8-6.6 8-12A8 8 0 1 0 4 10c0 5.4 8 12 8 12Z"/><circle cx="12" cy="10" r="3"/></svg>
              </div>
              <span className="font-black text-slate-950">LadGEO Admin</span>
            </div>
            <div className="p-4"><Sidebar mobile /></div>
          </div>
        </div>
      )}

      <div className="flex min-h-screen">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-slate-200/80 bg-white/70 backdrop-blur-xl">
          {/* Logo */}
          <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-100">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg">
              <svg viewBox="0 0 24 24" className="h-5 w-5 fill-none stroke-current" strokeWidth="2"><path d="M12 22s8-6.6 8-12A8 8 0 1 0 4 10c0 5.4 8 12 8 12Z"/><circle cx="12" cy="10" r="3"/></svg>
            </div>
            <div>
              <p className="font-black text-slate-950 text-base">LadGEO</p>
              <p className="text-xs text-slate-400">Admin Portal</p>
            </div>
          </div>

          {/* Nav */}
          <div className="flex-1 p-4 overflow-y-auto"><Sidebar /></div>

          {/* Back to planner */}
          <div className="p-4 border-t border-slate-100">
            <button onClick={onBack}
              className="w-full flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-600 hover:bg-white hover:border-blue-300 hover:text-blue-700 transition">
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
              Back to Route Planner
            </button>
          </div>
        </aside>

        {/* Main content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Top bar */}
          <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-slate-200/80 bg-white/80 backdrop-blur-xl px-4 py-4 lg:px-6">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition">
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
              </button>
              <div>
                <h1 className="text-lg font-black text-slate-950 capitalize">{page === "dashboard" ? "Overview Dashboard" : page}</h1>
                <p className="text-xs text-slate-400 hidden sm:block">{new Date().toLocaleDateString("en-NG", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2">
                <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-semibold text-slate-600">System Online</span>
              </div>
              <button onClick={onBack}
                className="lg:hidden rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-600 hover:border-blue-300 hover:text-blue-600 transition">
                ← Planner
              </button>
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-950 text-white text-xs font-black shadow">AD</div>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
            {page === "dashboard" && <PageDashboard orders={orders} drivers={drivers} fleet={fleet} />}
            {page === "orders" && <PageOrders orders={orders} setOrders={setOrders} drivers={drivers} />}
            {page === "drivers" && <PageDrivers drivers={drivers} setDrivers={setDrivers} />}
            {page === "fleet" && <PageFleet fleet={fleet} setFleet={setFleet} />}
            {page === "analytics" && <PageAnalytics orders={orders} drivers={drivers} fleet={fleet} />}
            {page === "settings" && <PageSettings settings={settings} setSettings={setSettings} />}
          </main>

          <footer className="text-center text-xs text-slate-400 py-4 border-t border-slate-100">
            LadGEO Admin © {new Date().getFullYear()} · All rights reserved
          </footer>
        </div>
      </div>
    </div>
  );
}
